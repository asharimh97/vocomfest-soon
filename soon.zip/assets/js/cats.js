var cats = ['kimi', 'komo', 'kumu'] ;
module.exports = cats ;