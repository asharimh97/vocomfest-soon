#Vocomfest 
Vocational Computer Festival is annual event held by Himpunan Mahasiswa Komputer dan Sistem Informasi (HIMAKOMSI) UGM
